import java.io.*;
import javax.servlet.*;
import java.sql.*;
public class pooja extends GenericServlet
{
	Connection con;
	public void init() throws ServletException
	{
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Art","root","root");
			}catch(Exception e)
		     {
				System.out.println(e);
			}
	}
	
	public void service(ServletRequest request,ServletResponse response)throws ServletException,IOException
	{
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		
		int pid=Integer.parseInt(request.getParameter("pid"));
		String title=request.getParameter("title");
		String type=request.getParameter("type");
		int year=Integer.parseInt(request.getParameter("year"));
		int aid=Integer.parseInt(request.getParameter("aid"));
		int rate=Integer.parseInt(request.getParameter("rate"));
		try {
			String query="insert into PAINTING values(?,?,?,?,?,?)";
			PreparedStatement ps=con.prepareStatement(query);
			
			ps.setInt(1,pid);
			ps.setString(2,title);
			ps.setString(3,type);
			ps.setInt(4,year);
			ps.setInt(5,aid);
			ps.setInt(6,rate);
			
			int i=ps.executeUpdate();
			if(i>0)
			{
				pw.println("VALUES INSERTED SUCCESSFULLY");
			}else
			{
				pw.println("VALUES DOES NOT INSERTED SUCCESSFULLY");
			}
			
		}catch(Exception e)
		{
			pw.println("ERROR"+e);
		}
		
		pw.println("<a href='Painting.html'>BACK</a>");
	}
}