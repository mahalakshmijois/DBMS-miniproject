import java.io.*;
import javax.servlet.*;
import java.sql.*;
public class Gallery_insert extends GenericServlet
{
	Connection con;
	public void init() throws ServletException
	{
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Art","root","root");
			}catch(Exception e)
		     {
				System.out.println(e);
			}
	}
	
	public void service(ServletRequest request,ServletResponse response)throws ServletException,IOException
	{
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		
		String gid=request.getParameter("gid");
		String gname=request.getParameter("gname");
		String aid=request.getParameter("aid");
		String pid=request.getParameter("pid");
		
		try {
			String query="insert into GALLERY values(?,?,?,?)";
			PreparedStatement ps=con.prepareStatement(query);
			
			ps.setString(1,gid);
			ps.setString(2,gname);
			ps.setString(3,aid);
			ps.setString(4,pid);
			
			int i=ps.executeUpdate();
			if(i>0)
			{
				pw.println("VALUES INSERTED SUCCESSFULLY");
			}else
			{
				pw.println("VALUES DOES NOT INSERTED SUCCESSFULLY");
			}
			
		}catch(Exception e)
		{
			pw.println("ERROR"+e);
		}
		pw.println("<a href='Gallery.html'>BACK</a>");		
		
	}
}