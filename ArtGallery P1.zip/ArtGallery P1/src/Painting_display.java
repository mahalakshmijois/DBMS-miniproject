import java.io.*;
import javax.servlet.*;
import java.sql.*;
public class Painting_display extends GenericServlet
{
	Connection con;
	public void init() throws ServletException {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Art","root","root");
		}catch(Exception e) {
			System.out.println(e);
		}
	}
		public void service (ServletRequest request,ServletResponse response) throws ServletException,IOException
	{
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		
		try{
			PreparedStatement st=con.prepareStatement("SELECT * FROM PAINTING");
		  
			ResultSet rs=st.executeQuery();
			pw.print("<center>");
			pw.print("<table border='4'>");
			pw.print("<tr width=600px>");
			pw.print("<th width=600px>"+"Panting id"+"</th>");
			pw.print("<th width=600px>"+"Type"+"</th>");
			pw.print("<th width=600px>"+"Title"+"</th>");
			pw.print("<th width=600px>"+"Year"+"</th>");
			pw.print("<th width=600px>"+"Artist id"+"</th>");
			pw.print("<th width=600px>"+"Rate"+"</th>");
			pw.print("</tr>");
		     while(rs.next())  
			{
		    	 pw.print("<tr>");
			String Pid=rs.getString("Pid");	
			String Type=rs.getString("Type");
			String Title=rs.getString("Title");
			String Year=rs.getString("Year");	
			String Aid=rs.getString("Aid");		
			String Rate=rs.getString("Rate");
			pw.print("<td width=35%>"+Pid+"</td>");
			pw.print("<td width=35%>"+Type+"</td>");
			pw.print("<td>"+Title+"</td>");
			pw.print("<td>"+Year+"</td>");
			pw.print("<td>"+Aid+"</td>");
			pw.print("<td>"+Rate+"</td>");
			pw.print("</tr>");
			   
			}
		     
				pw.print("</table>");
				pw.print("</center>");
		}catch(Exception e)
		{
			
			pw.println(e);
		}
		pw.println("<body style='background-color:#d3d3d3;'>");
		pw.print("<center><a href='links.html'>BACK</a>");
		pw.close();
	}
}
	
	