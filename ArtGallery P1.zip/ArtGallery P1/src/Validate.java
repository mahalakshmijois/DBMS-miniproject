import java.sql.*;

public class Validate
 {
     public static boolean checkUser(String username,String pass) 
     {
      boolean st =false;
      Connection con;
      try{

    	  Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Art","root","root");
         PreparedStatement ps =con.prepareStatement
                             ("select * from CUSTOMER where Username=? and Password=?");
         
		ps.setString(1, username);
         ps.setString(2, pass);
         ResultSet rs =ps.executeQuery();
         st = rs.next();
        
      }catch(Exception e)
      {
          e.printStackTrace();
      }
         return st;                 
  }   
}

