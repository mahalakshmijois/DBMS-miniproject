import java.io.*;
import javax.servlet.*;
import java.sql.*;
public class PaintingUpdt extends GenericServlet
{

	Connection con;
	public void init() throws ServletException {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Art","root","root");
		}catch(Exception e) {
			System.out.println(e);
		}
	}
		public void service (ServletRequest request,ServletResponse response) throws ServletException,IOException
	{
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		String Rate=request.getParameter("Rate");
		String Title=request.getParameter("Title");
		String Pid=request.getParameter("Pid");
		
		try{
			PreparedStatement st=con.prepareStatement("UPDATE PAINTING set Rate=?,Title=? where Pid=?");
		   st.setString(1,Rate);
		   st.setString(2,Title);
		   st.setString(3,Pid);
		st.executeUpdate();
		int i=st.executeUpdate();
		if(i>0)
			pw.println("Updated one row");
		else{
			pw.println("<br> row has been updated successfully");
		}
		}catch(Exception e)
		{
			
			pw.println(e);
		}
		 pw.println("one tuple Updated");
		pw.print("<center><a href='links.html'>BACK</a>");
		pw.close();
	}
}
	
	