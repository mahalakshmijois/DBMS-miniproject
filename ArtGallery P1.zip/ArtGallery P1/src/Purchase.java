import java.io.*;
import javax.servlet.*;
import java.sql.*;
public class Purchase extends GenericServlet
{
	Connection con;
	public void init() throws ServletException {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Art","root","root");
		}catch(Exception e) {
			System.out.println(e);
		}
	}
		public void service (ServletRequest request,ServletResponse response) throws ServletException,IOException
	{
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		String ptl=request.getParameter("Title");
		
		try{
			PreparedStatement st=con.prepareStatement("SELECT A.ANAME,G.GID,P.TITLE,P.RATE,P.PID"+" FROM ARTIST A,PAINTING P,GALLERY G"+" WHERE P.Title=? AND A.AID=P.AID AND P.PID=G.PID ");
			st.setString(1,ptl);
			
			ResultSet rs=st.executeQuery();
			pw.print("<table border='1'>");
			pw.print("<tr>");
			pw.print("<th>"+"ARTIST NAME"+"</th>");
			pw.print("<th>"+"PAINTING TITLE"+"</th>");
			pw.print("<th>"+"RATE"+"</th>");
			pw.print("<th>"+"GALLERY ID"+"</th>");
			pw.print("<th>"+"PAINTING ID"+"</th>");
			pw.print("</tr>");
		     while(rs.next())  
			{
		    	 pw.print("<tr>");
			String name=rs.getString("A.ANAME");	
			String title=rs.getString("P.TITLE");
			String rate=rs.getString("P.RATE");	
			String gid=rs.getString("G.GID");
			String pid=rs.getString("P.PID");
		
			pw.print("<td>"+name+"</td>");
			pw.print("<td>"+title+"</td>");
			pw.print("<td>"+rate+"</td>");
			pw.print("<td>"+gid+"</td>");
			pw.print("<td>"+pid+"</td>");
			pw.print("</tr>");
			   
			}
				pw.print("</table>");
		}
		catch(Exception e)
		{
			pw.println(e);
		}
		pw.print("<center><a href='BuyNow.html'>BUY NOW!!</a>");
		pw.print("<center><a href='Purchase.html'>BACK</a>");
		pw.close();
	}
}
	
	