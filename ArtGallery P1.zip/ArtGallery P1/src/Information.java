import java.io.*;
import javax.servlet.*;
import java.sql.*;
public class Information extends GenericServlet
{
	Connection con;
	public void init() throws ServletException {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Art","root","root");
		}catch(Exception e) {
			System.out.println(e);
		}
	}
		public void service (ServletRequest request,ServletResponse response) throws ServletException,IOException
	{
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		
		
		try{
			PreparedStatement st=con.prepareStatement("SELECT A.ANAME,P.TITLE,P.TYPE,P.YEAR " +
					"FROM ARTIST A,PAINTING P " +
			        "WHERE A.AID=P.AID");
		  
			ResultSet rs=st.executeQuery();
			pw.print("<table border='1'>");
			pw.print("<tr width=600px>");
			pw.print("<th width=600px>"+"ARTIST NAME"+"</th>");
			pw.print("<th width=600px>"+"TITLE"+"</th>");
			pw.print("<th width=600px>"+"TYPE"+"</th>");
			pw.print("<th width=600px>"+"YEAR"+"</th>");
			pw.print("</tr>");
		     while(rs.next())  
			{
		    	 pw.print("<tr>");
			String name=rs.getString("A.ANAME");	
			String title=rs.getString("P.TITLE");
			String type=rs.getString("P.TYPE");
			String year=rs.getString("P.YEAR");	
		
			
			pw.print("<td>"+name+"</td>");
			pw.print("<td>"+title+"</td>");
			pw.print("<td>"+type+"</td>");
			pw.print("<td>"+year+"</td>");
			pw.print("</tr>");
			   
			}
		     
				pw.print("</table>");
		}catch(Exception e)
		{
			
			pw.println(e);
		}
		pw.println("<body style='background-color:PeachPuff;'>");
		pw.print("<center><a href='Welcome.html'>BACK</a>");
		pw.close();
	}
}
	
	