import java.io.*;
import javax.servlet.*;
import java.sql.*;
public class ArtistUpdt extends GenericServlet
{

	Connection con;
	public void init() throws ServletException {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Art","root","root");
		}catch(Exception e) {
			System.out.println(e);
		}
	}
		public void service (ServletRequest request,ServletResponse response) throws ServletException,IOException
	{
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		String Address=request.getParameter("add");
		String Aid=request.getParameter("aid");
		
		try{
			PreparedStatement st=con.prepareStatement("UPDATE ARTIST set Address=? where Aid=?");
		   st.setString(1,Address);
		   st.setString(2,Aid);
		   
		st.executeUpdate();
		int i=st.executeUpdate();
		if(i>0)
			pw.println("Updated one row");
		else{
			pw.println("<br> row has been updated successfully");
		}
		}catch(Exception e)
		{
			
			pw.println(e);
		}
		
		pw.print("<center><a href='links.html'>BACK</a>");
		pw.close();
	}
}
	
	