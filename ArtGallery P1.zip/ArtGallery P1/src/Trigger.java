import java.io.*;
import javax.servlet.*;
import java.sql.*;
public class Trigger extends GenericServlet
{
	Connection con;
	public void init() throws ServletException {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Art","root","root");
		}catch(Exception e) {
			System.out.println(e);
		}
	}
		public void service (ServletRequest request,ServletResponse response) throws ServletException,IOException
	{
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		
		try{
			PreparedStatement st=con.prepareStatement("SELECT * FROM PCOUNTS");
		  
			ResultSet rs=st.executeQuery();
			pw.print("<table border='1'>");
			pw.print("<tr width=600px>");
			pw.print("<th width=600px>"+"Pcount id"+"</th>");
			pw.print("<th width=600px>"+"Type"+"</th>");
			pw.print("<th width=600px>"+"Counts"+"</th>");
			
			pw.print("</tr>");
		     while(rs.next())  
			{
		    	 pw.print("<tr>");
			String Pcid=rs.getString("Pcid");	
			String Type=rs.getString("Type");
			String Counts=rs.getString("Count");
		
				
			
			pw.print("<td>"+Pcid+"</td>");
			pw.print("<td>"+Type+"</td>");
			pw.print("<td>"+Counts+"</td>");
			
			
			pw.print("</tr>");
			   
			}
		     
				pw.print("</table>");
		}catch(Exception e)
		{
			
			pw.println(e);
		}
		pw.println("<body style='background-color:#f0b6b6;'>");
		pw.print("<center><a href='links.html'>BACK</a>");
		pw.close();
	}
}
	
	