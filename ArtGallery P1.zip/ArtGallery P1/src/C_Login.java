import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;
public class C_Login extends HttpServlet
{
	Connection con;
	public void init() throws ServletException {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Art","root","root");
		}catch(Exception e) {
			System.out.println(e);
		}
	}

	public void service (ServletRequest request,ServletResponse response) throws ServletException,IOException
		{
		
        response.setContentType("text/html");
        PrintWriter out = response.getWriter();
        
        String username = request.getParameter("username");
        String pass = request.getParameter("password");
        
        if(Validate.checkUser(username, pass))
        {
            RequestDispatcher rs = request.getRequestDispatcher("Purchase.html");
            rs.forward(request, response);
        }
        else
        {
           out.println("Username or Password incorrect");
           RequestDispatcher rs = request.getRequestDispatcher("links.html");
           rs.include(request, response);
        }
    }  
}
