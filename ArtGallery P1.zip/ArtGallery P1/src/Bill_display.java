import java.io.*;
import javax.servlet.*;
import java.sql.*;
public class Bill_display extends GenericServlet
{
	Connection con;
	public void init() throws ServletException {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Art","root","root");
		}catch(Exception e) {
			System.out.println(e);
		}
	}
		public void service (ServletRequest request,ServletResponse response) throws ServletException,IOException
	{
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		
		try{
			PreparedStatement st=con.prepareStatement("SELECT * FROM BILL");
		  
			ResultSet rs=st.executeQuery();
			pw.print("<table border='1'>");
			pw.print("<tr width=600px>");
			pw.print("<th width=600px>"+"Bill Id"+"</th>");
			pw.print("<th width=600px>"+"Artist Id"+"</th>");
			pw.print("<th width=600px>"+"Painting Id"+"</th>");
			pw.print("<th width=600px>"+"Customer Id"+"</th>");
			pw.print("<th width=600px>"+"Gallery Id"+"</th>");
			pw.print("<th width=600px>"+"Rate"+"</th>");
		
			pw.print("</tr>");
		     while(rs.next())  
			{
		    	 pw.print("<tr>");
			String Bid=rs.getString("Bid");	
			String Aid=rs.getString("Aid");
			String Pid=rs.getString("Pid");
			String Cid=rs.getString("Cid");	
			String Gid=rs.getString("Gid");
			String Rate=rs.getString("Rate");		
			
			pw.print("<td>"+Bid+"</td>");
			pw.print("<td>"+Aid+"</td>");
			pw.print("<td>"+Pid+"</td>");
			pw.print("<td>"+Cid+"</td>");
			pw.print("<td>"+Gid+"</td>");
			pw.print("<td>"+Rate+"</td>");
			
			pw.print("</tr>");
			   
			}
		     
				pw.print("</table>");
		}catch(Exception e)
		{
			
			pw.println(e);
		}
		pw.println("<body style='background-color:#f0b6b6;'>");
		pw.print("<center><a href='links.html'>BACK</a>");
		pw.close();
	}
}
	
	