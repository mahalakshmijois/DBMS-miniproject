import java.io.*;
import javax.servlet.*;
import java.sql.*;
public class Gallery_display extends GenericServlet
{
	Connection con;
	public void init() throws ServletException {
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Art","root","root");
		}catch(Exception e) {
			System.out.println(e);
		}
	}
		public void service (ServletRequest request,ServletResponse response) throws ServletException,IOException
	{
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		
		try{
			PreparedStatement st=con.prepareStatement("SELECT * FROM GALLERY");
		  
			ResultSet rs=st.executeQuery();
			pw.print("<table border='1'>");
			pw.print("<tr width=600px>");
			pw.print("<th width=600px>"+"Gallery id"+"</th>");
			pw.print("<th width=600px>"+"Gallery name"+"</th>");
			pw.print("<th width=600px>"+"Artist id"+"</th>");
			pw.print("<th width=600px>"+"Paiting id"+"</th>");
		
			pw.print("</tr>");
		     while(rs.next())  
			{
		    	 pw.print("<tr>");
			String Gid=rs.getString("Gid");	
			String Gname=rs.getString("Gname");
			String Aid=rs.getString("Aid");
			String Pid=rs.getString("Pid");	
				
			
			pw.print("<td>"+Gid+"</td>");
			pw.print("<td>"+Gname+"</td>");
			pw.print("<td>"+Aid+"</td>");
			pw.print("<td>"+Pid+"</td>");
			
			pw.print("</tr>");
			   
			}
		     
				pw.print("</table>");
		}catch(Exception e)
		{
			
			pw.println(e);
		}
		pw.println("<body style='background-color:#c6b8f7;'>");
		pw.print("<center><a href='links.html'>BACK</a>");
		pw.close();
	}
}
	
	