import java.io.*;
import javax.servlet.*;
import java.sql.*;
public class Bill_insert extends GenericServlet
{
	Connection con;
	public void init() throws ServletException
	{
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Art","root","root");
			}catch(Exception e)
		     {
				System.out.println(e);
			}
	}
	
	public void service(ServletRequest request,ServletResponse response)throws ServletException,IOException
	{
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		
	String bid=request.getParameter("bid");
	String aid=request.getParameter("aid");
	String pid=request.getParameter("pid");
	String cid=request.getParameter("cid");
	String gid=request.getParameter("gid");
	String rate=request.getParameter("rate");
		
		try {
			String query="insert into BILL values(?,?,?,?,?,?)";
			PreparedStatement ps=con.prepareStatement(query);
			
			ps.setString(1,bid);
			ps.setString(2,aid);
			ps.setString(3,pid);
			ps.setString(4,cid);
			ps.setString(5,gid);
			ps.setString(6,rate);
			int i=ps.executeUpdate();
			if(i>0)
			{
				pw.println("VALUES INSERTED SUCCESSFULLY");
			}else
			{
				pw.println("VALUES DOES NOT INSERTED SUCCESSFULLY");
			}
			
		}catch(Exception e)
		{
			pw.println("ERROR"+e);
		}
		pw.println("<a href='Bill.html'>BACK</a>");	
	}
}