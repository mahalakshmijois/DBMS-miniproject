import java.io.*;
import javax.servlet.*;
import java.sql.*;
public class Artist_insert extends GenericServlet
{
	Connection con;
	public void init() throws ServletException
	{
		try {
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/Art","root","root");
			}catch(Exception e)
		     {
				System.out.println(e);
			}
	}
	
	public void service(ServletRequest request,ServletResponse response)throws ServletException,IOException
	{
		response.setContentType("text/html");
		PrintWriter pw=response.getWriter();
		
		String aid=request.getParameter("aid");
		String aname=request.getParameter("aname");
		String address=request.getParameter("address");
		String phone=request.getParameter("phone");
		
		try {
			String query="insert into ARTIST values(?,?,?,?)";
			PreparedStatement ps=con.prepareStatement(query);
			
			ps.setString(1,aid);
			ps.setString(2,aname);
			ps.setString(3,address);
			ps.setString(4,phone);
			
			int i=ps.executeUpdate();
			if(i>0)
			{
				pw.println("VALUES INSERTED SUCCESSFULLY");
			}else
			{
				pw.println("VALUES DOES NOT INSERTED SUCCESSFULLY");
			}
			
		}catch(Exception e)
		{
			pw.println("ERROR"+e);
		}
		pw.println("<a href='Artist.html'>BACK</a>");
		
	}
}